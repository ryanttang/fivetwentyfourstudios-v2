# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2024-06-09
### Added
- Initial release: React 19, Vite, Tailwind, Framer Motion, Swiper.js, modular components, accessibility improvements, ThemeForest-ready documentation and packaging. 